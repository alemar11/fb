import UIKit
import SwiftUI

extension AnyTransition {
    static var moveAndFade: AnyTransition {
        .asymmetric(
            insertion: .opacity.animation(.bouncy),
            removal: .scale.combined(with: .opacity)
        )
    }
}

struct RootView: View {
    var didTapButton: () -> (UINavigationController)

    var body: some View {
        Button {
            withAnimation {
                let hosting = UIHostingController(rootView: SearchView().transition(.slide))
                didTapButton().pushViewController(hosting, animated: false)
            }
        } label: {
            Text("Tap this to show broken search bar animation")
        }
        .navigationTitle("First Page")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct SearchView: View {
    let items: [Int] = {
        (0...100).map {$0}
    }()

    @State var searchText: String = ""

    var body: some View {
        List {
            ForEach(items, id: \.self) { item in
                Text("\(item)")
            }
        }
        .listStyle(.plain)
        .navigationTitle("Search Page")
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $searchText, placement: .navigationBarDrawer(displayMode: .always), prompt: "Search")
    }
}
