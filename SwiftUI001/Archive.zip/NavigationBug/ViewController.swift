//
//  ViewController.swift
//  NavigationBug
//
//  Created by Brent Mifsud on 2023-10-19.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

